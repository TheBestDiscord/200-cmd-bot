exports.PREFIX = "?";

exports.OWNER_ID = "857072048568401964"


