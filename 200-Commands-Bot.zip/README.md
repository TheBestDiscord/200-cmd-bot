# 200-cmd-v2
a bot made by DEVELOPERS HQ 
